/*
 This enum is used when setting the game level
 */
package game;

/**
 *
 * @author Mahy
 */

public enum GameLevel {
    EASY, HARD
}
