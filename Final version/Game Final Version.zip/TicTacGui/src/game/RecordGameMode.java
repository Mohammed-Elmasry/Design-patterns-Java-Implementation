/*
 enum for recording mode
 */
package game;

/**
 *
 * @author Mahy
 */
public enum RecordGameMode {
    RECORD, NONE
}
