/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Mahy
 */
public abstract class Game {
    protected Board gameBoard;
    public final int PLAYER_ONE = 1;
    public final int PLAYER_TWO = 2;
    protected int currentTurn;
    
   public void setCurrentTurn(int turn) {
        this.currentTurn = turn;
    }
   
    public int getCurrentTurn() {
        return this.currentTurn;
    }
    
   public Board getGameBoard() {
        return gameBoard;
    }
   
    public abstract int checkBoardforWinner();
}
