/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Mahy
 */
public class HumanPlayer {

    private String username;
    private String firstName;
    private String lastName;
    private int playersTurn;
    private final int PLAYER_ONE = 1;
    private final int PLAYER_TWO = 2;

    public HumanPlayer(int playersTurn) {
        this.playersTurn = playersTurn;
    }

    private char getToken() {
        char token = 0;
        switch (playersTurn) {
            case PLAYER_ONE:
                token = 'X';
                break;
            case PLAYER_TWO:
                token = 'O';
        }
        return token;
    }

    public void performMove(String index, Board b) {
        int position = Integer.parseInt(index);
        char token = getToken();
        b.setBoardSlot(token, position);
    }
}
