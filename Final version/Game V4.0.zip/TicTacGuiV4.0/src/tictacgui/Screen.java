package tictacgui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Screen extends Pane {

    protected final ImageView imageView;
    protected final Button playButt;
    protected final Button playButt1;
    protected final Button settingButt3;

    public Screen(Stage stage) {

        imageView = new ImageView();
        playButt = new Button();
        playButt1 = new Button();
        settingButt3 = new Button();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(413.0);
        setPrefWidth(499.0);

        imageView.setFitHeight(413.0);
        imageView.setFitWidth(531.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("/images/mainMenu.png").toExternalForm()));

        playButt.setLayoutX(179.0);
        playButt.setLayoutY(174.0);
        playButt.setMnemonicParsing(false);
        playButt.setPrefHeight(65.0);
        playButt.setPrefWidth(174.0);
        playButt.setTextFill(javafx.scene.paint.Color.valueOf("#00000037"));
        playButt.setVisible(false);

        playButt1.setLayoutX(180.0);
        playButt1.setLayoutY(268.0);
        playButt1.setMnemonicParsing(false);
        playButt1.setPrefHeight(65.0);
        playButt1.setPrefWidth(174.0);
        playButt1.setTextFill(javafx.scene.paint.Color.valueOf("#00000037"));
        playButt1.setVisible(false);

        settingButt3.setLayoutX(21.0);
        settingButt3.setLayoutY(365.0);
        settingButt3.setMnemonicParsing(false);
        settingButt3.setPrefHeight(46.0);
        settingButt3.setPrefWidth(52.0);
        settingButt3.setVisible(false);

        getChildren().add(imageView);
        getChildren().add(playButt);
        getChildren().add(playButt1);
        getChildren().add(settingButt3);

    }
}
