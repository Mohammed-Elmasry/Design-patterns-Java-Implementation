/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictacgui;

import java.net.URL;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

/**
 *
 * @author Miramar
 */
public class TicTacGui extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        //Creating mediaplayer for setting the game music
        final URL resource = getClass().getResource("/music/Komiku.mp3");
        final Media media = new Media(resource.toString());
        final MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play(); //playing the music
        mediaPlayer.setOnEndOfMedia(new Runnable() {
            public void run() {
                //setting thr media to play on an infinite loop
                mediaPlayer.seek(Duration.ZERO);
            }
        });
        //starting the main stage
        Parent root = new Screen1(stage, mediaPlayer);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
