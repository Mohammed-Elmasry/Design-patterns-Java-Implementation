package tictacgui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public  class ChooseToken extends Pane {

    protected final ImageView imageView;
    protected final Button homeButt;
    protected final Button xButt;
    protected final ImageView imageView0;
    protected final Button oButt;
    protected final ImageView imageView1;
    protected final MediaPlayer mediaPlayer;

    public ChooseToken(Stage stage, MediaPlayer mediaPlayer) {

        imageView = new ImageView();
        homeButt = new Button();
        xButt = new Button();
        imageView0 = new ImageView();
        oButt = new Button();
        imageView1 = new ImageView();
        this.mediaPlayer = mediaPlayer;

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(500.0);
        setPrefWidth(606.0);

        imageView.setFitHeight(500.0);
        imageView.setFitWidth(606.0);
        imageView.setLayoutX(2.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("/images/tokenOptions.png").toExternalForm()));

        homeButt.setLayoutX(519.0);
        homeButt.setLayoutY(23.0);
        homeButt.setMnemonicParsing(false);
        homeButt.setOpacity(0.0);
        homeButt.setPrefHeight(56.0);
        homeButt.setPrefWidth(52.0);

        xButt.setLayoutX(167.0);
        xButt.setLayoutY(261.0);
        xButt.setMnemonicParsing(false);
        xButt.setPrefHeight(89.0);
        xButt.setPrefWidth(87.0);

        imageView0.setFitHeight(81.0);
        imageView0.setFitWidth(74.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("/images/xToken.png").toExternalForm()));
        xButt.setGraphic(imageView0);

        oButt.setLayoutX(370.0);
        oButt.setLayoutY(261.0);
        oButt.setMnemonicParsing(false);
        oButt.setPrefHeight(89.0);
        oButt.setPrefWidth(87.0);

        imageView1.setFitHeight(73.0);
        imageView1.setFitWidth(75.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("/images/oToken.png").toExternalForm()));
        oButt.setGraphic(imageView1);

        getChildren().add(imageView);
        getChildren().add(homeButt);
        getChildren().add(xButt);
        getChildren().add(oButt);
             homeButt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
              Parent root = new Screen1(stage,mediaPlayer);
             
             Scene scene = new Scene(root);
             stage.setScene(scene);
            stage.show();
            }
        });
             
             

           oButt.setOnAction(new EventHandler<ActionEvent>() {
            @Override 
               
            public void handle(ActionEvent event) {
            Parent root = new LocalScreen(stage,mediaPlayer);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            }
        });           
           
           
        xButt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
              Parent root = new LocalScreen(stage,mediaPlayer);
             
             Scene scene = new Scene(root);
             stage.setScene(scene);
            stage.show();
            }
        });

    }
}
